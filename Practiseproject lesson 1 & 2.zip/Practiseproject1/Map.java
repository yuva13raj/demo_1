package Practiseproject1;


	import java.util.*;
	import java.util.Map.Entry;
	public class Map {
			public static void main(String[] args) {
				// map
				
				//Hashmap
				HashMap<Integer,String> hm=new HashMap<Integer,String>();      
			      hm.put(1,"Ram");    
			      hm.put(2,"giri");    
			      hm.put(3,"dinesh");   
			       
			      System.out.println("\nThe elements of Hashmap are ");  
			      for(Entry<Integer, String> m:hm.entrySet()){    
			       System.out.println(m.getKey()+" "+m.getValue());    
			      }
			      
			     //HashTable
			       
			      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
			      
			      ht.put(4,"raju");  
			      ht.put(5,"praneesh");  
			      ht.put(6,"ramesh");  
			      ht.put(7,"ramu");  

			      System.out.println("\nThe elements of HashTable are ");  
			      for(Entry<Integer, String> n:ht.entrySet()){    
			       System.out.println(n.getKey()+" "+n.getValue());    
			      }
			      
			      
			      //TreeMap
			      
			      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
			      map.put(8,"durai");    
			      map.put(9,"harnesh");    
			      map.put(10,"hari");       
			      
			      System.out.println("\nThe elements of TreeMap are ");  
			      for(Entry<Integer, String> l:map.entrySet()){    
			       System.out.println(l.getKey()+" "+l.getValue());    
			      }    
			      
			   }  
}
