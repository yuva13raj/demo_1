package Practiseproject1;

public class innerclass {
	
		public void dispaly() {
				
				class Inner{
					
					int a=50;
					
					void print() 
					{
						System.out.println("Method of inner class");
						System.out.println("Value of a : "+a);
					}
					
				}
				
				Inner inner= new Inner();
				inner.print();
				
				
				
			}
			
			public static void main(String[] args) {
				
				innerclass outer= new innerclass();
				outer.dispaly();
				
			}
			
			
}
