package com.spexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDownloadExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDownloadExampleApplication.class, args);
	}

}
