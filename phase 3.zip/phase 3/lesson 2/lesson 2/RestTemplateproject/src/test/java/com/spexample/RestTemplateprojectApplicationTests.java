package com.spexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
