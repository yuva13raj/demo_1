package com.spexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstspringbootProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstspringbootProject1Application.class, args);
	}

}
