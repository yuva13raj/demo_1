package com.spexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstspringbootProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
