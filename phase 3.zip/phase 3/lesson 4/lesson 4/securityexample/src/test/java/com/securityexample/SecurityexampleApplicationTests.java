package com.securityexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
