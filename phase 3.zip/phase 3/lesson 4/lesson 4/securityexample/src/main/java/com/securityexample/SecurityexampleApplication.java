package com.securityexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityexampleApplication.class, args);
	}

}
