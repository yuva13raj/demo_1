package Assistedprojects;
import java.util.Scanner;

public class Arithmeticcalculator {
		public static void main(String[] args) 
		{
			
		Scanner scr=new Scanner(System.in); 
		 
		 
		 System.out.println("Choose an operator: +,-,*, or /");
		 char operator=scr.next().charAt(0);
		
		 System.out.println("Enter the First Input");
		 int Input1=scr.nextInt();
		
		 System.out.println("Enter the second Input");
		 int Input2=scr.nextInt();
		 scr.close();
		 int Result;
		 
		 switch(operator)
		 {
		   case '+':
			   Result=Input1+Input2;
			   System.out.println(Input1+ " + " + Input2+ " = " +Result);
			   break;
		   case '-':
			   Result=Input1-Input2;
			   System.out.println(Input1+ " - " + Input2+ " = " +Result);
			   break;
		   case '*':
			   Result=Input1*Input2;
			   System.out.println(Input1+ " * " + Input2+ " = " +Result);
			   break;
		   case '/':
			   Result=Input1/Input2;
			   System.out.println(Input1+ " / " + Input2+ " = " +Result);
			   break;
		   default:
			   System.out.println("Invalid operator!");
			   break;
	     
		 }
		 
		}

	}

