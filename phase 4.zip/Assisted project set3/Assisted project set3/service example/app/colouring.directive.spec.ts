import { ColouringDirective } from './colouring.directive';

describe('ColouringDirective', () => {
  it('should create an instance', () => {
    const directive = new ColouringDirective();
    expect(directive).toBeTruthy();
  });
});
