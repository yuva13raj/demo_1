import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppsService } from './apps.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ColouringDirective } from './colouring.directive';
import { TempchangePipe } from './tempchange.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ColouringDirective,
    TempchangePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [AppsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
