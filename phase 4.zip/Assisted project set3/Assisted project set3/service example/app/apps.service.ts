import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppsService {

  constructor() { }

  getapp():string {
    return"Hello world";
  }
  getproduct():Array<any>{
    return [ { name:"rice",price:500},
               { name:"sugar",price:100}
          ];
  }
}
