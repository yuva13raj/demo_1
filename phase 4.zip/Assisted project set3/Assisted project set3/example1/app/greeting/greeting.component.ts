import { Component, EventEmitter, Input, OnInit,Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-greeting',
  templateUrl: './greeting.component.html',
  styleUrls: ['./greeting.component.css']
})
export class GreetingComponent implements OnInit {

  constructor() { }

@Input()  productList: Array<any>=[];


ngOnInit(): void {}


name : string ="Bashi";

isDisabled= false;


  greet():void{
      alert("Hello "+this.name);
  };
  public clickCount:number=0;
@Output() onChanged=new EventEmitter<number>();

countChange(count : number){
  count++;
  this.clickCount=count;
  this.onChanged.emit(this.clickCount);
}
}