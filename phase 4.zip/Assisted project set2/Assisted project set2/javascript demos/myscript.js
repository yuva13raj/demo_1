<script>
// using alert
alert('Hello World');
</script>