// console.log("hi");
let num:any=55;
console.log("sum:" +(num+40));
num="Dolly";
console.log("sum:" +num);