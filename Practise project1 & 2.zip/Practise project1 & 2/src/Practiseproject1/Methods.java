package Practiseproject1;

public class Methods {

	  public int multiplyNumbers(int A, int B) {
	    int multiply = A * B;
	    return multiply;
	  }
	  public static void main(String[] args) {
	    int num1 = 22;
	    int num2 = 16;
	    Methods obj = new Methods();
	    int result = obj.multiplyNumbers(num1, num2);
	    System.out.println("Multiply is: " + result);
	  }
}
