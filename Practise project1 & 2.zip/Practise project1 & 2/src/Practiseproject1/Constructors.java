package Practiseproject1;

public class Constructors {

	  private String name;
	  Constructors() {
	    System.out.println("Constructor Called:");
	    name = "JAVA Constructors";
	   
	  }
	  public static void main(String[] args) {
	    Constructors object = new Constructors();
	    System.out.println("The name is " + object.name);
	    
	  }
}
