package Assistedprojects;
import java.util.ArrayList;
import java.util.Scanner;
public class validationofemail {
			public static void main(String[] args) {
				Scanner input = new Scanner(System.in);
				ArrayList<String> mail = new ArrayList<String>();
				mail.add("moulees38@gmail.com");
				mail.add("gowtham@gmail.com");
				mail.add("praneesh43@gmail.com");
				mail.add("dhivya11@gmail.com");
				mail.add("nithish567@gmail.com");
				System.out.println("ENTER USER EMAIL ID:");
				String userId = input.nextLine();
				//checks user mail id and shows found or not
					if (mail.contains(userId)) {
						System.out.println();
						System.out.println("Email ID " + userId + " found");
					} 
					else {
						System.out.println("Email ID " + userId + " Not found");

					}
				}
			}

